<?php
include 'db.php'; // Conexión a la base de datos
$sql = "SELECT * FROM productos ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos | TecnologiDEP</title>
    <link rel="stylesheet" href="assets/css/Style_productos.css">
</head>
<body>
    <header class="header">
        <img src="assets/Img/TecnologiDEP.png" alt="Logo TecnologiDEP" class="logo">
        <nav>
            <a href="Index.php">Inicio</a>
            <a href="Productos.php" class="activo">Productos</a>
            <a href="/PD/Carrito.php" class="carrito-link"> Carrito </a>
            <a href="/PD/Ingreso.php" class="carrito-link"> Iniciar Sesion </a>
            <a href="/PD/registro.php" class="carrito-link"> Registrarse </a>
        </nav>
    </header>

    <main class="container">
        <h1>Productos</h1>
        <p class="intro">Explora nuestros productos tecnológicos más destacados.</p>

        <div class="productos-grid">
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($producto = mysqli_fetch_assoc($result)): ?>
                    <div class="producto-card">
                        <img src="../<?php echo $producto['imagen']; ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                        <h3><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                        <p><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                        <strong>$<?php echo number_format($producto['precio'],0,',','.'); ?></strong>
                        <div class="acciones">
                            <a href="ProductoDetalle.php?id=<?php echo $producto['id']; ?>" class="btn-ver">Ver</a>
                            <form method="post" action="Carrito.php">
                                <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
                                <input type="hidden" name="nombre" value="<?php echo htmlspecialchars($producto['nombre']); ?>">
                                <input type="hidden" name="precio" value="<?php echo $producto['precio']; ?>">
                                <button type="submit" class="btn-comprar">Comprar</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No hay productos disponibles.</p>
            <?php endif; ?>
        </div>
    </main>
<br><br><br><br>
    <footer>
        <p>© 2025 TecnologiDEP - Daniel Esteban Parrado</p>
    </footer>
</body>
</html>