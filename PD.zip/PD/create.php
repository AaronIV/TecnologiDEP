<?php
include 'db.php';
session_start();

$error = '';
$success = '';

$upload_dir = "uploads/"; 
$allowed_types = ['jpg','jpeg','png','gif'];
$max_size = 2 * 1024 * 1024; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $apellido = mysqli_real_escape_string($conn, $_POST['apellido']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $telefono = mysqli_real_escape_string($conn, $_POST['telefono']);
    $direccion = mysqli_real_escape_string($conn, $_POST['direccion']);
    $puesto = mysqli_real_escape_string($conn, $_POST['puesto']);
    $salario = mysqli_real_escape_string($conn, $_POST['salario']);
    $fecha_contratacion = mysqli_real_escape_string($conn, $_POST['fecha_contratacion']);

    if (empty($nombre) || empty($apellido) || empty($email) || empty($telefono) || empty($puesto)) {
        $error = 'Los campos nombre, apellido, email, teléfono y puesto son obligatorios';
    } else {
        $foto = '';
        if(isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK){
            $file_name = $_FILES['foto']['name'];
            $file_tmp  = $_FILES['foto']['tmp_name'];
            $file_size = $_FILES['foto']['size'];
            $file_ext  = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if(in_array($file_ext, $allowed_types)){
                if($file_size <= $max_size){
                    $foto = uniqid('emp_', true).'.'.$file_ext;
                    move_uploaded_file($file_tmp, $upload_dir.$foto);
                } else { $error = 'La imagen es demasiado grande. Máx 2MB'; }
            } else { $error = 'Solo se permiten JPG, JPEG, PNG, GIF'; }
        }

        if(empty($error)){
            $sql = "INSERT INTO empleado (nombre, apellido, email, telefono, direccion, puesto, salario, fecha_contratacion, foto)
                    VALUES ('$nombre','$apellido','$email','$telefono','$direccion','$puesto','$salario','$fecha_contratacion','$foto')";
            if(mysqli_query($conn, $sql)){
                $success = "Empleado agregado exitosamente";
                header("refresh:2; url=exito.php"); 
                exit();
            } else { $error = "⚠️ Error al agregar empleado: " . mysqli_error($conn); }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agregar Empleado | Sistema Tech</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
<style>
    body { background-color: #f0f2f5; font-family: 'Poppins', sans-serif; }
    .form-container {
        max-width: 900px;
        margin: 3rem auto;
        padding: 2.5rem;
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 15px 40px rgba(0,0,0,0.1);
    }
    h1 { color: #6a11cb; font-weight: 700; margin-bottom: 2rem; }
    .form-label { font-weight: 500; }
    input.form-control, input.form-control:focus { 
        border-radius: 12px; 
        transition: all 0.3s; 
    }
    input.form-control:focus { border-color: #6a11cb; box-shadow: 0 0 8px rgba(106,17,203,0.2); }
    .btn-primary { 
        background: linear-gradient(135deg,#6a11cb,#2575fc); 
        border-radius: 12px; 
        font-weight: 600; 
        transition: all 0.3s;
    }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    .btn-secondary { border-radius: 12px; }
    .alert { border-radius: 12px; font-weight: 500; }
</style>
</head>
<body>
<div class="form-container">
    <h1>Agregar Nuevo Empleado</h1>

    <?php if(!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if(!empty($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <form action="create.php" method="post" enctype="multipart/form-data">
        <div class="row g-3">
            <div class="col-md-6">
                <input type="text" name="nombre" class="form-control" placeholder="Nombre" required>
                <input type="text" name="apellido" class="form-control mt-3" placeholder="Apellido" required>
                <input type="email" name="email" class="form-control mt-3" placeholder="Email" required>
                <input type="text" name="telefono" class="form-control mt-3" placeholder="Teléfono" required>
                <input type="text" name="direccion" class="form-control mt-3" placeholder="Dirección" required>
            </div>
            <div class="col-md-6">
                <input type="text" name="puesto" class="form-control" placeholder="Puesto" required>
                <input type="number" name="salario" class="form-control mt-3" placeholder="Salario" required>
                <input type="date" name="fecha_contratacion" class="form-control mt-3" required>
                <input type="file" name="foto" class="form-control mt-3" accept="image/*">
            </div>
        </div>
        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Guardar Empleado</button>
            <a href="exito.php" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>
</body>
</html>