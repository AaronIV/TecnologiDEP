<?php
session_start();
if(!isset($_SESSION['usuario'])){
    header("location: ingreso.php");
    exit();
}

$usuario = $_SESSION['usuario'];
require 'db.php'; 
$upload_dir = "uploads/"; // Carpeta de fotos
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Empleados | Sistema Tech</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f2f5;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 3rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }

        .dashboard-container h2 {
            font-weight: 500;
            color: #333;
        }

        .dashboard-container h1 {
            font-weight: 700;
            color: #6a11cb;
            margin-bottom: 2rem;
        }

        .btn-primary, .btn-info, .btn-warning, .btn-danger {
            border-radius: 12px;
            padding: 0.6rem 1.2rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-primary:hover { background: #2575fc; }
        .btn-info:hover { background: #17a2b8; }
        .btn-warning:hover { background: #e0a800; color: #fff; }
        .btn-danger:hover { background: #c82333; }

        table.table {
            font-size: 1rem;
            margin-bottom: 0;
        }

        table.table th, table.table td {
            vertical-align: middle;
            text-align: center;
            padding: 1rem 0.75rem;
        }

        table.table img {
            border-radius: 50%;
            object-fit: cover;
        }

        .logout-btn {
            background-color: #333;
            color: #fff;
            border-radius: 12px;
            padding: 0.6rem 1.2rem;
            font-weight: 500;
            transition: all 0.3s ease;
            margin-top: 1.5rem;
        }

        .logout-btn:hover { background-color: #000; }

        @media (max-width: 992px) {
            .dashboard-container { padding: 1.5rem; }
            table.table th, table.table td { font-size: 0.9rem; }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h2>Bienvenido(a), <?php echo htmlspecialchars($usuario); ?></h2>
        <h1>Gestión de Empleados</h1>
        <a href="create.php" class="btn btn-primary mb-4">Agregar nuevo empleado</a>

        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Puesto</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM empleado ORDER BY id DESC";
                    $result = mysqli_query($conn, $sql);

                    if(mysqli_num_rows($result) > 0){
                        while($row = mysqli_fetch_assoc($result)){
                            $foto = !empty($row['foto']) ? $row['foto'] : 'default-user.png';
                    ?>
                    <tr>
                        <td><?php echo $row['id']?></td>
                        <td><img src="<?php echo $upload_dir . $foto; ?>" alt="Foto" width="60" height="60"></td>
                        <td><?php echo $row['nombre'] . ' ' . $row['apellido']; ?></td>
                        <td><?php echo $row['email'] ?></td>
                        <td><?php echo $row['puesto'] ?></td>
                        <td>
                            <a href="view.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este empleado?')">Eliminar</a>
                        </td>
                    </tr>
                    <?php
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No hay empleados registrados</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <a href="./cerrar_sesion.php" class="d-block text-end">
            <button type="button" class="logout-btn">Cerrar sesión</button>
        </a>
    </div>
</body>
</html>