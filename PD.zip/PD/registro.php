<?php
require 'db.php';
$mensaje = ""; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["usuario"]) && isset($_POST["contrasena"])) {
        $usuario = trim($_POST['usuario']);
        $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);

        $sql = "INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $usuario, $contrasena);

        if (mysqli_stmt_execute($stmt)) {
            header("location:ingreso.php");
            exit();
        } else {
            $mensaje = "Error: El usuario ya existe.";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro | Sistema Tech</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/Botones.css">
    <style>
        /* RESET */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; }

        /* CONTENEDOR */
        .registro-container {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 400px;
            text-align: center;
            animation: fadeIn 0.8s ease-out;
        }

        /* TITULO */
        .registro-container h1 {
            margin-bottom: 1rem;
            font-size: 2rem;
            color: #333;
        }

        .registro-container p {
            margin-bottom: 2rem;
            color: #666;
            font-size: 0.95rem;
        }

        /* ALERTA */
        .alert-error {
            background-color: #ffe6e6;
            color: #cc0000;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }

        /* FORMULARIO */
        form { display: flex; flex-direction: column; gap: 1.25rem; }
        input {
            padding: 0.85rem 1rem;
            border-radius: 12px;
            border: 1px solid #ddd;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        input:focus { border-color: #6a11cb; box-shadow: 0 0 8px rgba(106,17,203,0.2); outline: none; }

        /* BOTON */
        button {
            padding: 0.85rem;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        button:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }

        /* FOOTER LINK */
        .footer-link {
            margin-top: 1rem;
            font-size: 0.9rem;
            color: #555;
        }
        .footer-link a {
            color: #6a11cb;
            text-decoration: none;
            font-weight: 600;
        }
        .footer-link a:hover { text-decoration: underline; }

        /* ANIMACION */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="registro-container">
        <h1>Crea tu cuenta</h1>
        <p>Regístrate y comienza a explorar nuestras funciones.</p>
        <?php if ($mensaje): ?><div class="alert-error"><?php echo $mensaje; ?></div><?php endif; ?>
        <form action="" method="post">
            <input type="text" name="usuario" placeholder="Usuario" required>
            <input type="password" name="contrasena" placeholder="Contraseña" required>
            <button type="submit">Registrarme</button>
        </form>
        <br>
        <a href="Index.php" class="btn-primary">Regresar a la página</a>
        <p class="footer-link">¿Ya tienes cuenta? <a href="ingreso.php">Inicia sesión</a></p>
    </div>
</body>
</html>