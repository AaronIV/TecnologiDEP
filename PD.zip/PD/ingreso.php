<?php
session_start();
require 'db.php';
$mensaje = ""; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["usuario"]) && isset($_POST["contrasena"])) {
        $usuario = trim($_POST["usuario"]);
        $contrasena = $_POST["contrasena"];

        $sql = "SELECT id, contrasena FROM usuarios WHERE usuario = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $usuario);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $id, $hash);

        if (mysqli_stmt_fetch($stmt) && password_verify($contrasena, $hash)) {
            $_SESSION['usuario'] = $usuario;
            $_SESSION['id'] = $id;
            header("location:exito.php"); 
            exit();
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ingreso | Sistema Tech</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/Botones.css">
    <style>
        /* RESET */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; }

        /* CONTENEDOR */
        .login-container {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            padding: 3rem 2.5rem;
            width: 100%;
            max-width: 400px;
            text-align: center;
            animation: fadeIn 0.8s ease-out;
        }

        /* TITULO */
        .login-container h1 {
            margin-bottom: 1rem;
            font-size: 2rem;
            color: #333;
        }

        .login-container p {
            margin-bottom: 2rem;
            color: #666;
            font-size: 0.95rem;
        }

        /* ALERTA */
        .alert-error {
            background-color: #ffe6e6;
            color: #cc0000;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }

        /* FORMULARIO */
        form { display: flex; flex-direction: column; gap: 1.25rem; }
        input {
            padding: 0.85rem 1rem;
            border-radius: 12px;
            border: 1px solid #ddd;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        input:focus { border-color: #2575fc; box-shadow: 0 0 8px rgba(37,117,252,0.2); outline: none; }

        /* BOTON */
        button {
            padding: 0.85rem;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #2575fc, #6a11cb);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        button:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }

        /* FOOTER LINK */
        .footer-link {
            margin-top: 1rem;
            font-size: 0.9rem;
            color: #555;
        }
        .footer-link a {
            color: #2575fc;
            text-decoration: none;
            font-weight: 600;
        }
        .footer-link a:hover { text-decoration: underline; }

        /* ANIMACION */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Bienvenido</h1>
        <p>Inicia sesión para acceder a tu plataforma.</p>
        <?php if ($mensaje): ?><div class="alert-error"><?php echo $mensaje; ?></div><?php endif; ?>
        <form action="" method="post">
            <input type="text" name="usuario" placeholder="Usuario" required>
            <input type="password" name="contrasena" placeholder="Contraseña" required>
            <button type="submit">Ingresar</button>
        </form>
        <br>
        <a href="Index.php" class="btn-primary">Regresar a la página</a>
        <p class="footer-link">¿No tienes cuenta? <a href="registro.php">Regístrate</a></p>
    </div>
</body>
</html>