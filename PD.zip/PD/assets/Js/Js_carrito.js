document.addEventListener("DOMContentLoaded", () => {

    const botonesComprar = document.querySelectorAll(".btn-comprar");
    const carritoContenedor = document.getElementById("carrito-contenedor");
    const totalCompra = document.querySelector("#total-compra strong");
    const vaciarBtn = document.getElementById("vaciar-carrito");

    let carrito = JSON.parse(localStorage.getItem("carrito")) || [];

    // 🛒 Añadir producto
    if (botonesComprar) {
        botonesComprar.forEach(boton => {
            boton.addEventListener("click", () => {
                const nombre = boton.dataset.nombre;
                const precio = parseFloat(boton.dataset.precio);

                carrito.push({ nombre, precio });
                localStorage.setItem("carrito", JSON.stringify(carrito));
                alert(`${nombre} añadido al carrito ✅`);
            });
        });
    }

    // 📦 Mostrar carrito en la página carrito.html
    if (carritoContenedor) {
        mostrarCarrito();
    }

    // 🗑 Vaciar carrito
    if (vaciarBtn) {
        vaciarBtn.addEventListener("click", () => {
            carrito = [];
            localStorage.removeItem("carrito");
            mostrarCarrito();
        });
    }

    function mostrarCarrito() {
        carritoContenedor.innerHTML = "";
        let total = 0;

        if (carrito.length === 0) {
            carritoContenedor.innerHTML = "<p>No hay productos en el carrito.</p>";
        } else {
            carrito.forEach(item => {
                const div = document.createElement("div");
                div.classList.add("item-carrito");
                div.innerHTML = `
                    <p><strong>${item.nombre}</strong> - $${item.precio.toFixed(2)}</p>
                `;
                carritoContenedor.appendChild(div);
                total += item.precio;
            });
        }

        totalCompra.textContent = `$${total.toFixed(2)}`;
    }
});
