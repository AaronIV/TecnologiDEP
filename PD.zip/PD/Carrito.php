<?php
// Carrito.php
session_start();
include 'db.php'; // Conexión a la base de datos

// Inicializar carrito en sesión si no existe
if(!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Manejar eliminación de productos o vaciado del carrito
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['vaciar'])) {
        $_SESSION['carrito'] = [];
    } elseif (isset($_POST['id'])) {
        $id = $_POST['id'];
        if(isset($_SESSION['carrito'][$id])) {
            unset($_SESSION['carrito'][$id]);
        }
    }
}

// Calcular total
$total = 0;
foreach($_SESSION['carrito'] as $item) {
    $total += $item['precio'] * $item['cantidad'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito - TecnologiDEP</title>
    <link rel="stylesheet" href="assets/css/Syle_carrito.css">
</head>
<body>

<header>
    <img src="Img/TecnologiDEP.png" alt="Logo TecnologiDEP" class="logo" sizes="100px">
    <h1>Tu Carrito de Compras</h1>
</header>

<nav>
    <a href="Index.php">Inicio</a>
    <a href="Productos.php">Productos</a>
    <a href="/PD/Ingreso.php" class="carrito-link"> Iniciar Sesion </a>
    <a href="/PD/registro.php" class="carrito-link"> Registrarse </a>
    <a href="Carrito.php" class="activo">🛒 Carrito</a>
</nav>

<main>
    <h2>Resumen de tus productos</h2>

    <?php if(!empty($_SESSION['carrito'])): ?>
        <div id="carrito-contenedor">
            <?php foreach($_SESSION['carrito'] as $id => $producto): ?>
                <div class="producto-carrito">
                    <img src="<?php echo $producto['imagen']; ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                    <div class="info-producto">
                        <h3><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                        <p>Cantidad: <?php echo $producto['cantidad']; ?></p>
                        <p>Precio unitario: $<?php echo number_format($producto['precio'],0,',','.'); ?></p>
                        <p>Subtotal: $<?php echo number_format($producto['precio'] * $producto['cantidad'],0,',','.'); ?></p>
                        <form method="post" action="Carrito.php">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <button type="submit">Eliminar</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div id="total-compra">
            Total: <strong>$<?php echo number_format($total,0,',','.'); ?></strong>
        </div>

        <form method="post" action="Carrito.php">
            <button type="submit" name="vaciar" id="vaciar-carrito">Vaciar carrito</button>
        </form>

    <?php else: ?>
        <p>Tu carrito está vacío.</p>
    <?php endif; ?>
</main>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>
    <p>© 2025 TecnologiDEP. Todos los derechos reservados - Daniel Esteban Parrado</p>
</footer>

</body>
</html>