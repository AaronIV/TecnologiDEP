<?php
// index.php
include 'db.php'; // Conexión a la base de datos

// Obtener productos desde la base de datos
$sql = "SELECT * FROM productos ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>TecnologiDEP</title>
    <link rel="stylesheet" href="assets/css/Style_index.css" />
</head>

<body>
    <header class="site-header">
        <div class="header-inner">
            <img src="assets/Img/TecnologiDEP.png" alt="Logo TecnologiDEP" class="logo">
            <nav class="main-nav">
                <a href="#">Inicio</a>
                <a href="/pd/Productos.php">Productos</a>
                <a href="/PD/Carrito.php" class="carrito-link"> Carrito </a>
                <a href="/PD/Ingreso.php" class="carrito-link"> Iniciar Sesion </a>
                <a href="/PD/registro.php" class="carrito-link"> Registrarse </a>
            </nav>
        </div>
    </header>

    <section class="hero">
        <div class="hero-img-container">
            <img src="assets/Img/Fondo.jpg" alt="Fondo TecnologiDEP" width="100" height="100">
        </div>
        <div class="hero-content">
            <h1>Bienvenido a TecnologiDEP</h1>
            <p>Encuentra los mejores productos tecnológicos al mejor precio</p>
        <a href="/PD/Productos.php" class="btn-primary">Ver productos</a>
    </div>
</section>
    <main>
        <h2>Conoce TecnologiDEP</h2>
        <p>Somos una tienda apasionada por la innovación y la tecnología. Aquí encontrarás lo mejor en equipos,
            periféricos y componentes de última generación.</p>

        <div class="video-presentacion">
            <iframe width="700" height="400" src="https://www.youtube.com/embed/RbaKP9hj8Sg?si=r8-YeZBvUa1O3IO2"
                title="Video TecnologiDEP" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
            </iframe>
        </div>
    </main>

    <main id="productos">
        <h2>Productos destacados</h2>
        <div class="productos-container">
            <?php if(mysqli_num_rows($result) > 0): ?>
                <?php while($producto = mysqli_fetch_assoc($result)): ?>
                    <div class="producto">
                        <img src="<?php echo $producto['imagen']; ?>" alt="<?php echo htmlspecialchars($producto['nombre']); ?>">
                        <h3><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                        <p><?php echo htmlspecialchars($producto['descripcion']); ?></p>
                        <strong>Precio: $<?php echo number_format($producto['precio'],0,',','.'); ?></strong>
                        <a href="/ProductoDetalle.php?id=<?php echo $producto['id']; ?>" class="btn-ver">Ver más</a>
                        <form method="post" action="/Carrito.php" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
                            <input type="hidden" name="nombre" value="<?php echo htmlspecialchars($producto['nombre']); ?>">
                            <input type="hidden" name="precio" value="<?php echo $producto['precio']; ?>">
                            <button type="submit" class="btn-comprar">Comprar</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No hay productos disponibles.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>© 2025 TecnologiDEP. Todos los derechos reservados - Daniel Esteban Parrado Castilo</p>
    </footer>
</body>

</html>